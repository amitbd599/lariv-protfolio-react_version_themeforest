const Education = [
  {
    title: "Software Engineer",
    institute: "Cirro Stratus Inc.",
    time: "May 2018–Present",
    text: "Liaised with Product Managers to identify minimum viable product requirements and clearly defined feature sets into well-scoped user stories for individual team members scripts to improve continuous integration practices top of Kubernetes.",
  },
  {
    title: "Bachelor of Computer Science",
    institute: "Carnegie Mellon University",
    time: "2014-2018",
    text: "Liaised with Product Managers to identify minimum viable product requirements and clearly defined feature sets into well-scoped user stories for individual team members scripts to improve continuous integration practices top of Kubernetes.",
  },
  {
    title: "Masters of Sciences",
    institute: "Uniex Pro University",
    time: "2012-2014",
    text: "Liaised with Product Managers to identify minimum viable product requirements and clearly defined feature sets into well-scoped user stories for individual team members scripts to improve continuous integration practices top of Kubernetes.",
  },
  {
    title: "Bachelor of Sciences",
    institute: "University of Oregon",
    time: "2009-2012",
    text: "Liaised with Product Managers to identify minimum viable product requirements and clearly defined feature sets into well-scoped user stories for individual team members scripts to improve continuous integration practices top of Kubernetes.",
  },
  {
    title: "Higher Secondary School",
    institute: "Delta institute",
    time: "2006-2010",
    text: "Liaised with Product Managers to identify minimum viable product requirements and clearly defined feature sets into well-scoped user stories for individual team members scripts to improve continuous integration practices top of Kubernetes.",
  },
];

export default Education;
